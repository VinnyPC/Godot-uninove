# CRT Monitor Effect Shader for Godot Engine 3.2 later

## TODO

いっぱい

## License

MIT License

## Author

* @arlez80 あるる / きのもと 結衣 ( Yui Kinomoto )

## Video

https://www.youtube.com/watch?v=AE04NlESIHA
